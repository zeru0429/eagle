const query = require('../config/db');
const userQuery = require('../querys/user.query');

const userService = {
   getAlluser: async ()=>{
     try{
      const rows = await query(userQuery.getAlluser);
      return rows;
     }
     catch(e){
      console.log(e);
      return null;
     }

   },
   getSingleuser: async (id)=>{
      try{
       const rows = await query(userQuery.getSingleuser,[id]);
       return rows;
      }
      catch(e){
       console.log(e);
       return null;
      }
 
    },

    updateSingleuser: async (id)=>{
      try{
       const rows = await query(userQuery.updateSingleuser,[id]);
       return rows;
      }
      catch(e){
       console.log(e);
       return null;
      }
 
    },

    deleteSingleuser: async (id)=>{
      try{
       const rows = await query(userQuery.deleteSingleuser,[id]);
       return rows;
      }
      catch(e){
       console.log(e);
       return null;
      }
 
    },

    createSingleuser: async (data)=>{
      try{
       const rows = await query(userQuery.createSingleuser,[data.englishName,data.amharicName]);
       return rows;
      }
      catch(e){
       console.log(e);
       return null;
      }
 
    },




}

module.exports = userService;