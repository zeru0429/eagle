const userQuery = {
   getAllUsers: `select * from users;`,
   getSingleUsers: `select * from users where userId = ?;`,
   deleteSingleUsers: `delete from users where userId = ?;`,
   updateSingleUsers: `update users set username = ?, password = ? where userId = ?;`,
   createSingleUsers: `insert into users (username, password) values (?, ?);`,
}

module.exports = userQuery;
