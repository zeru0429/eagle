const orderQuery = {
   getAllOrders: `select * from orders;`,
   getSingleOrder: `select * from orders where orderId = ?;`,
   deleteSingleOrder: `delete from orders where orderId = ?;`,
   updateSingleOrder: `update orders set waiterId = ?, userId = ? where orderId = ?;`,
   createSingleOrder: `insert into orders (waiterId, userId) values (?, ?);`,
   createSingleOrders: `insert into singleOrder (orderId, foodId) values (?, ?);`,
}

module.exports = orderQuery;
