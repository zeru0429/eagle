const express = require('express');

const orderRoutes = express.Router();


// include routes
orderRoutes.get('/api/order',(req,res)=>{
   res.send("order");
});

orderRoutes.get('/api/order',(req,res)=>{
   res.send("all order");
});
orderRoutes.get('/api/order/:id',(req,res)=>{
   res.send("single order");
});
orderRoutes.put('/api/order/:id',(req,res)=>{
   res.send("update single order");
});

orderRoutes.delete('/api/order/:id',(req,res)=>{
   res.send("delate single order");
});



module.exports =orderRoutes;

