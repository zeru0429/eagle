const express = require('express');

const foodRoutes = express.Router();


// include routes
// include routes
foodRoutes.get('/api/food',(req,res)=>{
   res.send("food");
});

foodRoutes.get('/api/food',(req,res)=>{
   res.send("all food");
});
foodRoutes.get('/api/food/:id',(req,res)=>{
   res.send("single food");
});
foodRoutes.put('/api/food/:id',(req,res)=>{
   res.send("update single food");
});

foodRoutes.delete('/api/food/:id',(req,res)=>{
   res.send("delate single food");
});



module.exports =foodRoutes;

