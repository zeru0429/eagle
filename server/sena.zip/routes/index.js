const express = require('express');

const  appRoutes = express.Router();

// import ms routes
const categoryRoutes = require('./category.route');
const foodRoutes = require('./food.route');
const orderRoutes = require('./order.route');
const userRoutes = require('./user.route');

// include routes
appRoutes.use(categoryRoutes);
appRoutes.use(foodRoutes);
appRoutes.use(orderRoutes);
appRoutes.use(userRoutes);



module.exports = appRoutes;

