const express = require('express');

const userRoutes = express.Router();


// include routes
userRoutes.get('/api/user',(req,res)=>{
   res.send("user");
});

userRoutes.get('/api/user',(req,res)=>{
   res.send("all user");
});
userRoutes.get('/api/user/:id',(req,res)=>{
   res.send("single user");
});
userRoutes.put('/api/user/:id',(req,res)=>{
   res.send("update single user");
});

userRoutes.delete('/api/user/:id',(req,res)=>{
   res.send("delate single user");
});


module.exports =userRoutes;

