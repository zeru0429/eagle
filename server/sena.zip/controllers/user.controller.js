

const userController ={
   getAlluser: (req,res)=>{
      console.log(req.body);

   },

   getSingluser: (req,res)=>{
      console.log(req.body);

   },

   deleteuser: (req,res)=>{
      console.log(req.body);

   },

   updateuser: (req,res)=>{
      console.log(req.body);

   },

   createuser: (req,res)=>{
      console.log(req.body);

   },



}

module.exports = userController;