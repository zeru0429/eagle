

const orderController ={
   getAllorder: (req,res)=>{
      console.log(req.body);

   },

   getSinglorder: (req,res)=>{
      console.log(req.body);

   },

   deleteorder: (req,res)=>{
      console.log(req.body);

   },

   updateorder: (req,res)=>{
      console.log(req.body);

   },

   createorder: (req,res)=>{
      console.log(req.body);

   },



}

module.exports = orderController;