

const foodController ={
   getAllfood: (req,res)=>{
      console.log(req.body);

   },

   getSinglfood: (req,res)=>{
      console.log(req.body);

   },

   deletefood: (req,res)=>{
      console.log(req.body);

   },

   updatefood: (req,res)=>{
      console.log(req.body);

   },

   createfood: (req,res)=>{
      console.log(req.body);

   },



}

module.exports = foodController;